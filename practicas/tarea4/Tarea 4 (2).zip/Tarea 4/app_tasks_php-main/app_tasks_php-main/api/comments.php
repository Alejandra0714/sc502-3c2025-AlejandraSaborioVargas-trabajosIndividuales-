<?php
session_start();

header("Access-Control-Allow-Origin: *"); 
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

$userId = $_SESSION['user_id'];

// Obtener el método de la solicitud
$method = $_SERVER['REQUEST_METHOD'];

// Lee el cuerpo de la solicitud 
$data = json_decode(file_get_contents("php://input"), true);

switch ($method) {
    case 'GET':

        $taskId = $_GET['task_id'] ?? null;
        // Obtener todos los comments del usuario
        $stmt = $conn->prepare("SELECT id, description, create_at FROM comments WHERE userId = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $tasks = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($comments);
        break;

    case 'POST':
        $taskid = $data['id'] ?? '';
        $description = $data['description'] ?? '';
        

        if ($taskid && $description) {
            $stmt = $conn->prepare("INSERT INTO comments (userId, taskid, description, create_at) VALUES (?, ?, ? NOW())");
            $stmt->bind_param("iis", $userId, $taskid, $description);
            $stmt->execute();
            echo json_encode(['success' => true, 'comments_id' => $stmt->insert_id]);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Campos incompletos']);
        }
        break;

    case 'PUT':
        $commentId = $data['id'] ?? null;
        $description = $data['description'] ?? '';
       

        if ($commentid && $description) {
            $stmt = $conn->prepare("UPDATE comments SET description = ? WHERE id AND userId ?");
            $stmt->bind_param("sii", $description, $commentId, $userId);
            $stmt->execute();
            echo json_encode(['success' => true]);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Datos incompletos']);
        }
        break;

    case 'DELETE':
        $commentId = $data['id'] ?? null;

        if ($id) {
            $stmt = $conn->prepare("DELETE FROM comments WHERE id = ? AND userId = ?");
            $stmt->bind_param("ii", $commentId, $userId);
            $stmt->execute();
            echo json_encode(['success' => true]);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'ID no proporcionado']);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
        break;
}
